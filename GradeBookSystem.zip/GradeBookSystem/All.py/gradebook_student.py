import tkinter as tk
from tkinter import messagebox
import sqlite3

def open_transcript_page():
    window = tk.Tk()
    window.title("Student Transcript Page")
    window.geometry("500x400")

    tk.Label(window, text="Student Transcript", font=("Arial", 18)).pack(pady=10)

    student_id = tk.StringVar()

    tk.Label(window, text="Enter Student ID:").pack()
    tk.Entry(window, textvariable=student_id).pack()

    def show_transcript():
        sid = student_id.get().strip()
        conn = sqlite3.connect("gradebook.db")
        cur = conn.cursor()
        cur.execute("SELECT name, math, science, english, life_orientation, geography, afrikaans, accounting FROM students WHERE student_id=?", (sid,))
        row = cur.fetchone()
        conn.close()

        if row:
            name, math, science, english, life_orientation, geography, afrikaans, accounting = row
            avg = (math + science + english + life_orientation + geography + afrikaans + accounting) / 7
            grade = "A" if avg >= 90 else "B" if avg >= 80 else "C" if avg >= 70 else "D" if avg >= 60 else "F"
            performance = "Pass" if avg >= 50 else "Fail"
            result = f"\nName: {name}\nMath: {math}\nScience: {science}\nEnglish: {english}\nLife Orientation: {life_orientation}\nGeography: {geography}\nAfrikaans: {afrikaans}\nAccounting: {accounting}\nGPA: {avg:.2f}\nGrade: {grade}\nPerformance: {performance}"
        else:
            result = "Student ID not found."

        # Clear previous results (if any)
        for widget in window.pack_slaves():
            if isinstance(widget, tk.Label) and widget != window.children['!label']:
                widget.destroy()

        tk.Label(window, text=result, font=("Arial", 12), justify="left").pack(pady=10)

    tk.Button(window, text="Show Transcript", command=show_transcript).pack(pady=5)
    tk.Button(window, text="Exit", command=window.destroy).pack(pady=10)

    window.mainloop()
