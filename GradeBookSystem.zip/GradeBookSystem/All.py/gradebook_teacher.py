import tkinter as tk
from tkinter import messagebox, Text, Toplevel, Entry, Label, Button
from PIL import Image, ImageTk
import sqlite3

def init_db():
    conn = sqlite3.connect("gradebook.db")
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS students (
            student_id TEXT PRIMARY KEY,
            name TEXT,
            math REAL,
            science REAL,
            english REAL,
            life_orientation REAL,
            geography REAL,
            afrikaans REAL,
            accounting REAL
        )
    """)
    conn.commit()
    conn.close()

class GradebookApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Student Gradebook System")
        self.root.state('zoomed')
        self.root.configure(bg="#f0f0f0")

        self.create_widgets()

    def create_widgets(self):
        try:
            logo_img = Image.open("logo.jpg")
            logo_img = logo_img.resize((150, 150), Image.Resampling.LANCZOS)
            logo = ImageTk.PhotoImage(logo_img)
            self.logo_label = tk.Label(self.root, image=logo, bg="#f0f0f0")
            self.logo_label.image = logo
            self.logo_label.pack(pady=(20, 0))
        except Exception as e:
            print(f"Logo load failed: {e}")

        heading = tk.Label(self.root, text="Student Gradebook System", font=("Helvetica", 28, "bold"),
                           bg="#f0f0f0", fg="#3e3e3e")
        heading.pack(pady=(10, 20))

        btn_params = {"width": 20, "padx": 10, "pady": 5}
        Button(self.root, text="Add Student", command=self.add_student, **btn_params).pack()
        Button(self.root, text="Update Student", command=self.update_student, **btn_params).pack()
        Button(self.root, text="Delete Student", command=self.delete_student, **btn_params).pack()
        Button(self.root, text="View All Students", command=self.view_students, **btn_params).pack()
        Button(self.root, text="View Transcript", command=self.view_transcript, **btn_params).pack()
        Button(self.root, text="Calculate Average GPA", command=self.calculate_average, **btn_params).pack(pady=(20,5))
        Button(self.root, text="Exit", bg="red", fg="white", command=self.root.quit, **btn_params).pack(pady=20)

    def add_student(self):
        self.open_form("Add Student", self.save_new_student)

    def update_student(self):
        self.open_form("Update Student", self.save_updated_student, update=True)

    def delete_student(self):
        win = Toplevel(self.root)
        win.title("Delete Student")
        win.geometry("350x150")

        Label(win, text="Enter Student ID to Delete:").pack(pady=10)
        student_id = Entry(win)
        student_id.pack(padx=15, fill='x')

        def delete():
            sid = student_id.get().strip()
            if not sid:
                messagebox.showerror("Error", "Student ID cannot be empty.")
                return
            conn = sqlite3.connect("gradebook.db")
            cur = conn.cursor()
            cur.execute("DELETE FROM students WHERE student_id=?", (sid,))
            if cur.rowcount == 0:
                messagebox.showerror("Error", "Student ID not found.")
            else:
                conn.commit()
                messagebox.showinfo("Success", "Student deleted successfully.")
            conn.close()
            win.destroy()

        Button(win, text="Delete", command=delete).pack(pady=15)

    def view_students(self):
        win = Toplevel(self.root)
        win.title("All Students")
        win.geometry("850x450")

        conn = sqlite3.connect("gradebook.db")
        cur = conn.cursor()
        cur.execute("SELECT student_id, name, math, science, english, life_orientation, geography, afrikaans, accounting FROM students")
        rows = cur.fetchall()
        conn.close()

        text_area = Text(win, wrap="none")
        text_area.pack(expand=True, fill="both")

        header = f"{'ID':<12}{'Name':<20}{'Math':<10}{'Science':<10}{'English':<10}" \
                 f"{'Life Orientation':<17}{'Geography':<12}{'Afrikaans':<12}{'Accounting':<12}\n"
        text_area.insert(tk.END, header)
        text_area.insert(tk.END, "-" * 115 + "\n")

        for row in rows:
            sid, name, math, science, english, life_orientation, geography, afrikaans, accounting = row
            line = f"{sid:<12}{name:<20}{math:<10}{science:<10}{english:<10}" \
                   f"{life_orientation:<17}{geography:<12}{afrikaans:<12}{accounting:<12}\n"
            text_area.insert(tk.END, line)

        text_area.config(state="disabled")

    def view_transcript(self):
        self.root.destroy()
        # Import here to avoid circular imports, and run the student transcript window
        from gradebook_student import open_transcript_page
        open_transcript_page()

    def calculate_average(self):
        conn = sqlite3.connect("gradebook.db")
        cur = conn.cursor()
        cur.execute("SELECT AVG((math + science + english + life_orientation + geography + afrikaans + accounting)/7) FROM students")
        avg = cur.fetchone()[0]
        conn.close()
        if avg is not None:
            messagebox.showinfo("Average GPA", f"Class Average GPA: {avg:.2f}")
        else:
            messagebox.showinfo("Average GPA", "No student data available.")

    def open_form(self, title, save_callback, update=False):
        win = Toplevel(self.root)
        win.title(title)
        win.geometry("450x550")

        fields = {}
        labels = ["Student ID", "Name", "Math", "Science", "English", "Life Orientation", "Geography", "Afrikaans", "Accounting"] if not update else \
                 ["Student ID to Update", "New Name", "New Math", "New Science", "New English", "New Life Orientation", "New Geography", "New Afrikaans", "New Accounting"]

        for label in labels:
            Label(win, text=f"{label}:", anchor="w").pack(fill="x", padx=15, pady=6)
            entry = Entry(win)
            entry.pack(fill="x", padx=15, pady=6)
            fields[label] = entry

        Button(win, text="Save", command=lambda: save_callback(fields, win)).pack(pady=20)

    def save_new_student(self, fields, win):
        try:
            conn = sqlite3.connect("gradebook.db")
            cur = conn.cursor()
            cur.execute("INSERT INTO students VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", (
                fields["Student ID"].get().strip(),
                fields["Name"].get().strip(),
                float(fields["Math"].get()),
                float(fields["Science"].get()),
                float(fields["English"].get()),
                float(fields["Life Orientation"].get()),
                float(fields["Geography"].get()),
                float(fields["Afrikaans"].get()),
                float(fields["Accounting"].get())
            ))
            conn.commit()
            conn.close()
            messagebox.showinfo("Success", "Student added successfully.")
            win.destroy()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to add student:\n{e}")

    def save_updated_student(self, fields, win):
        try:
            conn = sqlite3.connect("gradebook.db")
            cur = conn.cursor()
            cur.execute("UPDATE students SET name=?, math=?, science=?, english=?, life_orientation=?, geography=?, afrikaans=?, accounting=? WHERE student_id=?", (
                fields["New Name"].get().strip(),
                float(fields["New Math"].get()),
                float(fields["New Science"].get()),
                float(fields["New English"].get()),
                float(fields["New Life Orientation"].get()),
                float(fields["New Geography"].get()),
                float(fields["New Afrikaans"].get()),
                float(fields["New Accounting"].get()),
                fields["Student ID to Update"].get().strip()
            ))
            if cur.rowcount == 0:
                messagebox.showerror("Error", "Student ID not found.")
            else:
                conn.commit()
                messagebox.showinfo("Success", "Student updated successfully.")
            conn.close()
            win.destroy()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to update student:\n{e}")

# Call init_db when this file is imported (important!)
init_db()

