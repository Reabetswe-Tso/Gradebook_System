import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import sqlite3
from gradebook_teacher import GradebookApp
from gradebook_student import open_transcript_page

def init_db():
    conn = sqlite3.connect('gradebook.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            username TEXT PRIMARY KEY,
            password TEXT NOT NULL,
            role TEXT CHECK(role IN ('teacher', 'student')) NOT NULL
        )
    ''')
    # Insert default users if none exist
    c.execute("SELECT COUNT(*) FROM users")
    if c.fetchone()[0] == 0:
        users = [
            ('admin', 'admin123', 'teacher'),
            ('learner1', 'pass123', 'student')
        ]
        c.executemany("INSERT INTO users (username, password, role) VALUES (?, ?, ?)", users)
    conn.commit()
    conn.close()

def open_registration(root):
    reg_win = tk.Toplevel(root)
    reg_win.title("Register")
    reg_win.geometry("300x400")

    try:
        logo_image = Image.open("logo.jpg")
        logo_image = logo_image.resize((100, 100))
        logo_photo = ImageTk.PhotoImage(logo_image)
        logo_label = tk.Label(reg_win, image=logo_photo)
        logo_label.image = logo_photo
        logo_label.pack(pady=10)
    except:
        pass

    tk.Label(reg_win, text="New Username").pack(pady=5)
    new_user_entry = tk.Entry(reg_win)
    new_user_entry.pack()

    tk.Label(reg_win, text="New Password").pack(pady=5)
    new_pass_entry = tk.Entry(reg_win, show="*")
    new_pass_entry.pack()

    tk.Label(reg_win, text="Select Role").pack(pady=5)
    role_var = tk.StringVar()
    role_var.set("student")
    tk.OptionMenu(reg_win, role_var, "student", "teacher").pack()

    def register():
        username = new_user_entry.get()
        password = new_pass_entry.get()
        role = role_var.get()

        if not username or not password:
            messagebox.showerror("Error", "All fields are required")
            return

        conn = sqlite3.connect('gradebook.db')
        c = conn.cursor()
        try:
            c.execute("INSERT INTO users (username, password, role) VALUES (?, ?, ?)", (username, password, role))
            conn.commit()
            messagebox.showinfo("Success", "Registration successful!")
            reg_win.destroy()
        except sqlite3.IntegrityError:
            messagebox.showerror("Error", "Username already exists")
        finally:
            conn.close()

    tk.Button(reg_win, text="Register", command=register).pack(pady=10)

def login_screen():
    init_db()
    root = tk.Tk()
    root.title("Login")
    root.geometry("300x400")

    try:
        logo_image = Image.open("logo.jpg")
        logo_image = logo_image.resize((100, 100))
        logo_photo = ImageTk.PhotoImage(logo_image)
        logo_label = tk.Label(root, image=logo_photo)
        logo_label.image = logo_photo
        logo_label.pack(pady=10)
    except:
        pass

    tk.Label(root, text="Username").pack(pady=5)
    username_entry = tk.Entry(root)
    username_entry.pack()

    tk.Label(root, text="Password").pack(pady=5)
    password_entry = tk.Entry(root, show="*")
    password_entry.pack()

    def login():
        username = username_entry.get()
        password = password_entry.get()
        conn = sqlite3.connect('gradebook.db')
        c = conn.cursor()
        c.execute("SELECT role FROM users WHERE username=? AND password=?", (username, password))
        result = c.fetchone()
        conn.close()

        if result:
            role = result[0]
            root.destroy()

            if role == 'teacher':
                teacher_root = tk.Tk()
                app = GradebookApp(teacher_root)
                teacher_root.mainloop()
            else:
                open_transcript_page()
        else:
            messagebox.showerror("Error", "Invalid credentials")

    tk.Button(root, text="Login", command=login).pack(pady=10)
    tk.Button(root, text="Register", command=lambda: open_registration(root)).pack()

    root.mainloop()

if __name__ == "__main__":
    login_screen()
