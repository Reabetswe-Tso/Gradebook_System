import tkinter as tk
from tkinter import messagebox, ttk
import sqlite3
from PIL import Image, ImageTk

# Database setup
def create_database():
    conn = sqlite3.connect("gradebook.db")
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            math INTEGER,
            science INTEGER,
            english INTEGER,
            life_orientation INTEGER,
            geography INTEGER,
            afrikaans INTEGER,
            accounting INTEGER
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            username TEXT PRIMARY KEY,
            password TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('teacher', 'student'))
        )
    """)
    conn.commit()
    conn.close()

# Add dummy data
def add_dummy_data():
    conn = sqlite3.connect("gradebook.db")
    cur = conn.cursor()
    cur.execute("INSERT OR IGNORE INTO users (username, password, role) VALUES (?, ?, ?)", 
                ("teacher1", "pass123", "teacher"))
    cur.execute("INSERT OR IGNORE INTO users (username, password, role) VALUES (?, ?, ?)", 
                ("student1", "pass123", "student"))
    cur.execute("INSERT OR IGNORE INTO students (name, math, science, english, life_orientation, geography, afrikaans, accounting) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                ("student1", 75, 88, 92, 81, 79, 85, 90))
    conn.commit()
    conn.close()

# Login window
def login():
    def verify_credentials():
        username = username_entry.get()
        password = password_entry.get()

        conn = sqlite3.connect("gradebook.db")
        cur = conn.cursor()
        cur.execute("SELECT role FROM users WHERE username=? AND password=?", (username, password))
        result = cur.fetchone()
        conn.close()

        if result:
            role = result[0]
            login_window.destroy()
            if role == "teacher":
                messagebox.showinfo("Login", "Teacher dashboard would load here.")
                # You can call a teacher dashboard function here if you want
            elif role == "student":
                view_transcript(username)
        else:
            messagebox.showerror("Error", "Invalid credentials.")

    login_window = tk.Tk()
    login_window.title("Login")
    login_window.geometry("400x300")
    login_window.configure(bg="#ecf0f1")

    tk.Label(login_window, text="Login", font=("Helvetica", 18, "bold"), bg="#ecf0f1").pack(pady=20)

    tk.Label(login_window, text="Username:", bg="#ecf0f1").pack()
    username_entry = tk.Entry(login_window)
    username_entry.pack(pady=5)

    tk.Label(login_window, text="Password:", bg="#ecf0f1").pack()
    password_entry = tk.Entry(login_window, show="*")
    password_entry.pack(pady=5)

    tk.Button(login_window, text="Login", command=verify_credentials, bg="#2980b9", fg="white").pack(pady=20)

    login_window.mainloop()

# Transcript viewer
def view_transcript(username):
    window = tk.Tk()
    window.title("Transcript Viewer")
    window.geometry("600x500")
    window.configure(bg="#f4f6f7")

    # Add logo (if available)
    try:
        logo_image = Image.open("logo.jpg")
        logo_image = logo_image.resize((100, 100))
        logo_photo = ImageTk.PhotoImage(logo_image)
        logo_label = tk.Label(window, image=logo_photo, bg="#f4f6f7")
        logo_label.image = logo_photo
        logo_label.pack(pady=10)
    except Exception as e:
        print("Logo error:", e)

    tk.Label(
        window, 
        text=f"{username}'s Academic Transcript", 
        font=("Helvetica", 18, "bold"),
        bg="#f4f6f7",
        fg="#2c3e50"
    ).pack(pady=5)

    frame = tk.Frame(window, bg="#f4f6f7")
    frame.pack(pady=10, padx=20, fill="both", expand=True)

    columns = ("Subject", "Grade")
    tree = ttk.Treeview(frame, columns=columns, show="headings", height=10)

    style = ttk.Style()
    style.configure("Treeview.Heading", font=("Helvetica", 12, "bold"))
    style.configure("Treeview", font=("Helvetica", 11), rowheight=28)

    for col in columns:
        tree.heading(col, text=col)
        tree.column(col, anchor="center")

    tree.pack(fill="both", expand=True)

    # Fetch grades
    conn = sqlite3.connect("gradebook.db")
    cur = conn.cursor()
    cur.execute("SELECT * FROM students WHERE name = ?", (username,))
    result = cur.fetchone()
    conn.close()

    if result:
        _, name, math, science, english, lo, geo, afrikaans, acc = result
        grades = [
            ("Math", math),
            ("Science", science),
            ("English", english),
            ("Life Orientation", lo),
            ("Geography", geo),
            ("Afrikaans", afrikaans),
            ("Accounting", acc)
        ]
        for subject, grade in grades:
            tree.insert("", "end", values=(subject, grade))
    else:
        messagebox.showerror("Not Found", "Student not found in database.")

    tk.Button(
        window, text="Exit", command=window.destroy,
        bg="#d35400", fg="white", font=("Helvetica", 11, "bold"),
        relief="raised", padx=15, pady=5
    ).pack(pady=15)

    window.mainloop()

# Initialize database and launch login
if __name__ == "__main__":
    create_database()
    add_dummy_data()
    login()
